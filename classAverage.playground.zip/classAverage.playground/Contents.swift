import UIKit
//A variable that holds the name of each student in the class
var name = "Scott,Ruby ,Kamari, Donald, DeVonte ,Anna ,Desmon,Isaiah,Ikenna,Devon,Adarsh,  Raquel,Hayley,DeAntre,Tyler,  Khyree,Jasmine,Mackenzie,Keneisha,Michael,Sagar, Amarachi,Shantal,Stephone,Nkem,Dhruvkumar,Gaeshawn"

//print the total number of characters
print (name.count)

//create a variable that holds the sum of all students
var sum = 27

//create the average number of names in the class
let averageOfNames = sum / name.count
print(averageOfNames)

